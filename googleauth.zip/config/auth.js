module.exports = {
googleAuth: {
  clientID: '489331041513-k2t6gauja02clenm5vcdat7hjfladsvq.apps.googleusercontent.com',
 clientSecret: 'zuaQes4kYnoTjMAibbY1Tnqp',
 callbackURL: 'http://localhost:8080/auth/google/redirect',
  }
}
